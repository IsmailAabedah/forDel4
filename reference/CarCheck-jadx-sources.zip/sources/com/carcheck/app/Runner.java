package com.carcheck.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import android.provider.Settings;
import android.util.SparseArray;
import android.view.WindowManager;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
final class Runner {
    static final String D_BT = "com.zhonghong.bluetooth.aidl.IBtCtrlInterface";
    static final String D_BT_CB = "com.zhonghong.bluetooth.aidl.IBtDataCallback";
    static final String D_CAN = "com.zhonghong.cancommon.ICanInterface";
    static final String D_CAN_CB = "com.zhonghong.cancommon.ICanDataCallback";
    static final String D_LOGIC = "com.logic.common.aidl.ILogicInterface";
    static final String D_LOGIC_CB = "com.logic.common.aidl.ILogicCallback";
    static final String D_MCU = "android.zhonghong.IMcuService";
    static final String D_STATE = "com.zhonghong.aidlib.state.SystemStateInterface";
    static final String D_STATE_CB = "com.zhonghong.aidlib.state.SystemStateCallBack";
    static final String D_USB = "com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlInterface";
    static final String D_USB_L = "com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlListener";
    static final String D_VIDEO = "com.zhonghong.mediaaidl.video.IVideoAidlInterface";
    volatile Activity act;
    IBinder btB;
    IBinder canB;
    final Context ctx;
    Done done;
    final Log log;
    IBinder logicB;
    IBinder mcuB;
    IBinder stateB;
    IBinder usbB;
    IBinder videoB;
    volatile boolean everStarted = false;
    final Handler main = new Handler(Looper.getMainLooper());
    final SparseArray<byte[]> frames = new SparseArray<>();
    final List<ServiceConnection> conns = new ArrayList();
    volatile boolean recording = false;
    volatile long recEnd = 0;
    volatile boolean staticRunning = false;
    Map<String, Long> lastSnap = null;
    Map<String, Long> lastEvt = null;
    private final Cb canCb = new Cb(D_CAN_CB) { // from class: com.carcheck.app.Runner.1
        @Override // android.os.Binder
        protected boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel.enforceInterface(this.desc);
            final int i3 = parcel.readInt();
            if (parcel2 != null) {
                parcel2.writeNoException();
            }
            Runner.this.async(new Runnable() { // from class: com.carcheck.app.Runner.1.1
                @Override // java.lang.Runnable
                public void run() {
                    Runner.this.onCanEvent(i3);
                }
            });
            return true;
        }
    };
    private final Cb logicCb = new Cb(D_LOGIC_CB) { // from class: com.carcheck.app.Runner.2
        @Override // android.os.Binder
        protected boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel.enforceInterface(this.desc);
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            if (parcel2 != null) {
                parcel2.writeNoException();
            }
            Runner.this.log.line("EVENT logic: " + string + " | " + string2 + " | " + string3);
            return true;
        }
    };
    private final Cb btCb = new Cb(D_BT_CB) { // from class: com.carcheck.app.Runner.3
        @Override // android.os.Binder
        protected boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel.enforceInterface(this.desc);
            int i3 = parcel.readInt();
            String string = parcel.readString();
            if (parcel2 != null) {
                parcel2.writeNoException();
            }
            Runner.this.log.line("EVENT bt: domain=" + i3 + " value=" + Runner.maskDigits(string));
            return true;
        }
    };
    private final Cb stateCb = new Cb(D_STATE_CB) { // from class: com.carcheck.app.Runner.4
        @Override // android.os.Binder
        protected boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String[] strArr = {"", "headlamp", "volume", "btPhoneState", "acc", "btState", "network", "back", "power"};
            if (i < 1 || i > 8) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel.enforceInterface(this.desc);
            int i3 = parcel.readInt();
            if (parcel2 != null) {
                parcel2.writeNoException();
            }
            Runner.this.log.line("EVENT state: " + strArr[i] + " = " + i3);
            return true;
        }
    };
    private final Cb usbCb = new Cb(D_USB_L) { // from class: com.carcheck.app.Runner.5
        @Override // android.os.Binder
        protected boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1) {
                parcel.enforceInterface(this.desc);
                String string = parcel.readString();
                String string2 = parcel.readString();
                String string3 = parcel.readString();
                if (parcel2 != null) {
                    parcel2.writeNoException();
                }
                Runner.this.log.line("EVENT usbmusic id3: title.len=" + Runner.len(string) + " artist.len=" + Runner.len(string2) + " album.len=" + Runner.len(string3));
                return true;
            }
            if (i != 2) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel.enforceInterface(this.desc);
            int i3 = parcel.readInt();
            if (parcel2 != null) {
                parcel2.writeNoException();
            }
            Runner.this.log.line("EVENT usbmusic playState=" + i3);
            return true;
        }
    };
    private final String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());

    private abstract class Cb extends Binder {
        final String desc;

        Cb(String str) {
            this.desc = str;
            attachInterface(null, str);
        }
    }

    interface Done {
        void onDone(String str);
    }

    Runner(Activity activity, Log log) {
        this.act = activity;
        this.ctx = activity.getApplicationContext();
        this.log = log;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int len(String str) {
        if (str == null) {
            return -1;
        }
        return str.length();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String maskDigits(String str) {
        return str == null ? "null" : str.replaceAll("[0-9]{4,}", "<digits>").replaceAll("([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}", "<mac>");
    }

    static boolean noisy(String str) {
        return str.contains("Checksum") || str.contains("counter") || str.contains("Torque") || str.contains("Overal") || str.startsWith("ODO") || str.startsWith("Vehicle_Speed") || str.startsWith("is413");
    }

    void async(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setDaemon(true);
        thread.start();
    }

    void beepTest() {
        Intent intent = new Intent("com.zhonghong.android.key");
        intent.putExtra("data", 4608);
        this.ctx.sendBroadcast(intent);
        this.log.line("MARK beep broadcast sent (com.zhonghong.android.key data=4608) - did you hear a beep?");
    }

    IBinder bind(Intent intent, int i, String str) {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        final IBinder[] iBinderArr = new IBinder[1];
        ServiceConnection serviceConnection = new ServiceConnection() { // from class: com.carcheck.app.Runner.7
            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                iBinderArr[0] = iBinder;
                countDownLatch.countDown();
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName componentName) {
            }
        };
        try {
            boolean zBindService = this.ctx.bindService(intent, serviceConnection, 1);
            this.log.line(str + ": bindService returned " + zBindService);
            if (!zBindService) {
                return null;
            }
            try {
                countDownLatch.await(i, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
            }
            if (iBinderArr[0] != null) {
                this.conns.add(serviceConnection);
                return iBinderArr[0];
            }
            this.log.line(str + ": no onServiceConnected within " + i + " ms");
            try {
                this.ctx.unbindService(serviceConnection);
                return null;
            } catch (Throwable th) {
                return null;
            }
        } catch (Throwable th2) {
            this.log.line(str + ": bindService threw " + th2);
            return null;
        }
    }

    void btReads() {
        if (this.btB != null) {
            for (String str : new String[]{"getConnectState", "getEnableState", "getA2dpState", "getCallState", "getPlayState", "getCurBatteryVale", "getCurSignalStrength", "getDuration", "getCurPosition"}) {
                try {
                    Parcel parcelCall = Bx.call(this.btB, D_BT, 2, str, "");
                    this.log.line("bt getValue(" + str + ") = " + maskDigits(parcelCall.readString()));
                    parcelCall.recycle();
                } catch (Throwable th) {
                    this.log.line("bt getValue(" + str + ") failed: " + th);
                }
            }
            for (String str2 : new String[]{"getConnectDevice", "getDevices", "getName", "getAddress"}) {
                try {
                    Parcel parcelCall2 = Bx.call(this.btB, D_BT, 2, str2, "");
                    String string = parcelCall2.readString();
                    parcelCall2.recycle();
                    this.log.line("bt getValue(" + str2 + ") -> length " + len(string) + " (content hidden)");
                } catch (Throwable th2) {
                    this.log.line("bt getValue(" + str2 + ") failed: " + th2);
                }
            }
            try {
                Parcel parcelCall3 = Bx.call(this.btB, D_BT, 2, "getCalls", "");
                String string2 = parcelCall3.readString();
                parcelCall3.recycle();
                StringBuilder sb = new StringBuilder("bt getCalls raw length " + len(string2) + ": ");
                if (string2 == null || string2.length() <= 2) {
                    sb.append("(empty)");
                } else {
                    JSONArray jSONArray = new JSONArray(string2);
                    for (int i = 0; i < jSONArray.length(); i++) {
                        JSONObject jSONObject = jSONArray.getJSONObject(i);
                        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("call");
                        sb.append("[keys=").append(jSONObject.names()).append(" state=").append(jSONObjectOptJSONObject == null ? "?" : Integer.valueOf(jSONObjectOptJSONObject.optInt("state", -99))).append(" numberLen=").append(jSONObjectOptJSONObject == null ? -1 : jSONObjectOptJSONObject.optString("number", "").length()).append("] ");
                    }
                }
                this.log.line(sb.toString());
            } catch (Throwable th3) {
                this.log.line("bt getCalls parse failed: " + th3);
            }
        }
        this.log.line("sys.btcall = " + Bx.prop("sys.btcall"));
        ContentResolver contentResolver = this.ctx.getContentResolver();
        for (String str3 : new String[]{"bt_connected", "key_bluetooth_state", "key_signal_state", "key_battery_state"}) {
            this.log.line("Settings.System " + str3 + " = " + Settings.System.getString(contentResolver, str3));
        }
    }

    Map<String, Long> decodeAll() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        synchronized (this.frames) {
            for (Object[] objArr : CanSignals.S) {
                long jBits = Bx.bits(this.frames.get(((Integer) objArr[1]).intValue()), ((Integer) objArr[2]).intValue(), ((Integer) objArr[3]).intValue(), ((Integer) objArr[4]).intValue());
                if (jBits >= 0) {
                    linkedHashMap.put(objArr[0] + "@" + objArr[1], Long.valueOf(jBits));
                }
            }
        }
        return linkedHashMap;
    }

    String desc(IBinder iBinder) {
        try {
            return iBinder.getInterfaceDescriptor();
        } catch (Throwable th) {
            return "<err " + th + ">";
        }
    }

    /* JADX WARN: Code duplicated, block: B:45:0x011c  */
    void describe(String str, boolean z) throws Throwable {
        Cursor cursorQuery;
        String string;
        Cursor cursor = null;
        try {
            try {
                cursorQuery = this.ctx.getContentResolver().query(Uri.parse(str), null, null, null, null);
                try {
                    if (cursorQuery == null) {
                        this.log.line(str + " -> null cursor");
                        if (cursorQuery != null) {
                            cursorQuery.close();
                            return;
                        }
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    for (String str2 : cursorQuery.getColumnNames()) {
                        sb.append(str2).append(',');
                    }
                    this.log.line(str + " -> rows=" + cursorQuery.getCount() + " columns=" + ((Object) sb));
                    if (z && cursorQuery.moveToFirst()) {
                        StringBuilder sb2 = new StringBuilder("   first row: ");
                        for (int i = 0; i < cursorQuery.getColumnCount(); i++) {
                            try {
                                string = cursorQuery.getString(i);
                            } catch (Throwable th) {
                                string = "?";
                            }
                            String columnName = cursorQuery.getColumnName(i);
                            boolean z2 = string != null && string.matches("-?[0-9]{1,6}");
                            StringBuilder sbAppend = sb2.append(columnName).append('=');
                            if (!z2) {
                                string = string == null ? "null" : "<" + string.length() + " chars>";
                            }
                            sbAppend.append(string).append("  ");
                        }
                        this.log.line(sb2.toString());
                    }
                    if (cursorQuery != null) {
                        cursorQuery.close();
                    }
                } catch (Throwable th2) {
                    th = th2;
                    this.log.line(str + " -> " + th);
                    if (cursorQuery != null) {
                        cursorQuery.close();
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                if (0 != 0) {
                    cursor.close();
                }
                throw th;
            }
        } catch (Throwable th4) {
            th = th4;
            cursorQuery = null;
        }
    }

    boolean fetchCan(int i, boolean z) {
        IBinder iBinder = this.canB;
        if (iBinder == null) {
            return false;
        }
        Parcel parcel = null;
        try {
            try {
                Parcel parcelCall = Bx.call(iBinder, D_CAN, 5, Integer.valueOf(i));
                if (parcelCall.readInt() == 0) {
                    if (!z) {
                        this.log.line("CAN type " + i + ": no data");
                    }
                    if (parcelCall == null) {
                        return false;
                    }
                    parcelCall.recycle();
                    return false;
                }
                int i2 = parcelCall.readInt();
                StringBuilder sb = new StringBuilder();
                for (int i3 = 0; i3 < i2; i3++) {
                    int i4 = parcelCall.readInt();
                    int i5 = parcelCall.readByte() & 255;
                    byte[] bArr = new byte[i5];
                    if (i5 > 0) {
                        parcelCall.readByteArray(bArr);
                    }
                    synchronized (this.frames) {
                        this.frames.put(i4, bArr);
                    }
                    sb.append(i4).append('(').append(i5).append(") ");
                }
                if (!z) {
                    this.log.line("CAN type " + i + ": frames " + ((Object) sb));
                }
                if (parcelCall != null) {
                    parcelCall.recycle();
                }
                return true;
            } catch (Throwable th) {
                this.log.line("CAN fetch type " + i + " failed: " + th);
                if (0 != 0) {
                    try {
                        this.log.line("  reply raw: " + Bx.hex(parcel.marshall(), 120));
                    } catch (Throwable th2) {
                    }
                }
                if (0 == 0) {
                    return false;
                }
                parcel.recycle();
                return false;
            }
        } catch (Throwable th3) {
            if (0 != 0) {
                parcel.recycle();
            }
            throw th3;
        }
    }

    void keepAlive(boolean z) {
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) KeepAlive.class);
            if (z) {
                this.ctx.startService(intent);
            } else {
                this.ctx.stopService(intent);
            }
        } catch (Throwable th) {
            this.log.line("keepAlive(" + z + ") failed: " + th);
        }
    }

    void mark(final String str) {
        async(new Runnable() { // from class: com.carcheck.app.Runner.20
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.log.line("MARK " + str);
                for (int i = 1; i <= 4; i++) {
                    Runner.this.fetchCan(i, true);
                }
                Runner.this.snapshot("after " + str);
                Runner.this.log.line("  back_state=" + Settings.System.getString(Runner.this.ctx.getContentResolver(), "back_state") + " sys.btcall=" + Bx.prop("sys.btcall"));
            }
        });
    }

    String mcuQuery(IBinder iBinder, int i, int i2, String str) {
        String string;
        Parcel parcelObtain = Parcel.obtain();
        Parcel parcelObtain2 = Parcel.obtain();
        Parcel parcelObtain3 = Parcel.obtain();
        try {
            if (str != null) {
                try {
                    parcelObtain.writeByteArray(str.getBytes());
                } catch (Throwable th) {
                    string = "ERR " + th;
                    parcelObtain.recycle();
                    parcelObtain2.recycle();
                    parcelObtain3.recycle();
                }
            }
            parcelObtain2.writeInterfaceToken(D_MCU);
            parcelObtain2.writeInt(i);
            parcelObtain2.writeInt(i2);
            if (parcelObtain.dataSize() > 0) {
                parcelObtain2.appendFrom(parcelObtain, 0, parcelObtain.dataSize());
            }
            iBinder.transact(3, parcelObtain2, parcelObtain3, 0);
            int iDataSize = parcelObtain3.dataSize();
            parcelObtain3.setDataPosition(Math.max(0, iDataSize - 4));
            StringBuilder sb = new StringBuilder("ok=" + parcelObtain3.readInt() + " replyBytes=" + iDataSize);
            if (iDataSize > 4) {
                parcelObtain3 = Parcel.obtain();
                parcelObtain3.appendFrom(parcelObtain3, 0, iDataSize - 4);
                parcelObtain3.setDataPosition(0);
                try {
                    int i3 = parcelObtain3.readInt();
                    sb.append(" len=").append(i3).append(" type=").append(parcelObtain3.readInt());
                    if (i3 <= 1 || i3 > parcelObtain3.dataAvail()) {
                        sb.append(" (unexpected layout) rawHex=");
                        parcelObtain3.setDataPosition(0);
                        sb.append(Bx.hex(parcelObtain3.marshall(), 96));
                    } else {
                        byte[] bArr = new byte[i3];
                        parcelObtain3.readByteArray(bArr);
                        String str2 = new String(bArr, 0, i3 - 1);
                        StringBuilder sbAppend = sb.append(" text=");
                        if (str2.length() > 4000) {
                            str2 = str2.substring(0, 4000) + "...(cut)";
                        }
                        sbAppend.append(str2);
                    }
                    parcelObtain3.recycle();
                } finally {
                    parcelObtain3.recycle();
                }
            }
            string = sb.toString();
            parcelObtain.recycle();
            parcelObtain2.recycle();
            return string;
        } catch (Throwable th2) {
            parcelObtain.recycle();
            parcelObtain2.recycle();
            parcelObtain3.recycle();
            throw th2;
        }
    }

    void mcuReads() {
        for (int i = 1; i <= 3; i++) {
            this.log.line("domain " + i + " read-all {\"all\":0}: " + mcuQuery(this.mcuB, i, 1, "{\"all\":0}"));
        }
        this.log.line("domain 1 read WITHOUT input parcel (parcel variant): " + mcuQuery(this.mcuB, 1, 1, null));
        this.log.line("domain 8 offline-config {\"all\":0} cmd0: " + mcuQuery(this.mcuB, 8, 0, "{\"all\":0}"));
        for (String[] strArr : new String[][]{new String[]{"2", "SYS_VOL"}, new String[]{"2", "SYS_MUTE"}, new String[]{"2", "brightness"}, new String[]{"2", "EQ1k"}, new String[]{"3", "ACC_STATE"}, new String[]{"3", "BACK_SIGNAL"}, new String[]{"3", "ILL_STATE"}, new String[]{"3", "MCU_SOURCE"}, new String[]{"1", "getfreq"}}) {
            this.log.line("keyed read domain " + strArr[0] + " " + strArr[1] + ": " + mcuQuery(this.mcuB, Integer.parseInt(strArr[0]), 1, "{\"" + strArr[1] + "\":0}"));
        }
    }

    void onCanEvent(int i) {
        fetchCan(i, true);
        Map<String, Long> mapDecodeAll = decodeAll();
        Map<String, Long> map = this.lastEvt;
        if (map != null) {
            for (Map.Entry<String, Long> entry : mapDecodeAll.entrySet()) {
                Long l = map.get(entry.getKey());
                if (l == null || !l.equals(entry.getValue())) {
                    if (!noisy(entry.getKey())) {
                        this.log.line("CAN-CHG " + entry.getKey() + " " + l + " -> " + entry.getValue());
                    }
                }
            }
        }
        this.lastEvt = mapDecodeAll;
    }

    List<File> outDirs() {
        LinkedHashSet<File> linkedHashSet = new LinkedHashSet();
        File[] externalFilesDirs = this.ctx.getExternalFilesDirs(null);
        if (externalFilesDirs != null) {
            for (File file : externalFilesDirs) {
                if (file != null) {
                    linkedHashSet.add(file);
                }
            }
        }
        linkedHashSet.add(new File(Environment.getExternalStorageDirectory(), "CarCheck"));
        for (String str : new String[]{"/storage", "/mnt"}) {
            File[] fileArrListFiles = new File(str).listFiles();
            if (fileArrListFiles != null) {
                for (File file2 : fileArrListFiles) {
                    if (file2.isDirectory() && file2.canWrite()) {
                        linkedHashSet.add(new File(file2, "CarCheck"));
                    }
                }
            }
        }
        ArrayList arrayList = new ArrayList();
        for (File file3 : linkedHashSet) {
            file3.mkdirs();
            if (file3.isDirectory() && file3.canWrite()) {
                arrayList.add(file3);
            }
        }
        return arrayList;
    }

    void quickBt() {
        async(new Runnable() { // from class: com.carcheck.app.Runner.22
            @Override // java.lang.Runnable
            public void run() throws Throwable {
                Runner.this.log.line("MARK quick Bluetooth/call read");
                if (Runner.this.btB == null) {
                    Runner.this.btB = Bx.sm("zhbt_service");
                    Runner.this.log.line("zhbt_service lookup now -> " + (Runner.this.btB == null ? "null" : "binder"));
                    if (Runner.this.btB != null) {
                        for (int i = 1; i <= 3; i++) {
                            try {
                                Bx.call(Runner.this.btB, Runner.D_BT, 3, Integer.valueOf(i), Runner.this.btCb).recycle();
                            } catch (Throwable th) {
                            }
                        }
                    }
                }
                Runner.this.btReads();
                Runner.this.tProvidersBtOnly();
            }
        });
    }

    void quickMcu() {
        async(new Runnable() { // from class: com.carcheck.app.Runner.21
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.log.line("MARK quick MCU read");
                if (Runner.this.mcuB == null) {
                    Runner.this.mcuB = Bx.sm("zhonghong.mcu");
                }
                if (Runner.this.mcuB == null) {
                    Runner.this.log.line("zhonghong.mcu not available");
                } else {
                    Runner.this.mcuReads();
                }
            }
        });
    }

    void runStatic() {
        this.everStarted = true;
        keepAlive(true);
        this.staticRunning = true;
        this.log.line("CarCheck started");
        step("1. ENVIRONMENT", new Runnable() { // from class: com.carcheck.app.Runner.8
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tEnv();
            }
        });
        step("2. SYSTEM SERVICES PRESENCE", new Runnable() { // from class: com.carcheck.app.Runner.9
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tServices();
            }
        });
        step("3. CAN SERVICE (com.zhonghong.can)", new Runnable() { // from class: com.carcheck.app.Runner.10
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tCan();
            }
        });
        step("4. LOGIC SERVICE (_logic_service)", new Runnable() { // from class: com.carcheck.app.Runner.11
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tLogic();
            }
        });
        step("5. MCU SERVICE (zhonghong.mcu)", new Runnable() { // from class: com.carcheck.app.Runner.12
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tMcu();
            }
        });
        step("6. BLUETOOTH CONTROL SERVICE (zhbt_service)", new Runnable() { // from class: com.carcheck.app.Runner.13
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tBt();
            }
        });
        step("7. SYSTEM STATE BROKER (aidlserver)", new Runnable() { // from class: com.carcheck.app.Runner.14
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tState();
            }
        });
        step("8. USB MUSIC / VIDEO SERVICES", new Runnable() { // from class: com.carcheck.app.Runner.15
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tUsb();
            }
        });
        step("9. CONTENT PROVIDERS", new Runnable() { // from class: com.carcheck.app.Runner.16
            @Override // java.lang.Runnable
            public void run() throws Throwable {
                Runner.this.tProviders();
            }
        });
        step("10. OVERLAY WINDOW (for an incoming-call popup)", new Runnable() { // from class: com.carcheck.app.Runner.17
            @Override // java.lang.Runnable
            public void run() {
                Runner.this.tOverlay();
            }
        });
        this.staticRunning = false;
        this.log.section("STATIC CHECKS FINISHED");
        save();
    }

    void sample() {
        Map<String, Long> mapDecodeAll = decodeAll();
        this.log.line("SAMPLE back_state=" + Settings.System.getString(this.ctx.getContentResolver(), "back_state") + " sys.btcall=" + Bx.prop("sys.btcall") + " speed@1218=" + mapDecodeAll.get("Vehicle_Speed@1218") + " lever@1218=" + mapDecodeAll.get("Shifter_Lever_Signals@1218") + " odoBCM=" + mapDecodeAll.get("ODO_calculated_By_BCM@800") + " odoICM=" + mapDecodeAll.get("ODO_calculated_By_ICM@1219"));
    }

    synchronized String save() {
        StringBuilder sb;
        sb = new StringBuilder();
        try {
            byte[] bytes = this.log.text().getBytes("UTF-8");
            for (File file : outDirs()) {
                try {
                    for (String str : new String[]{"carcheck_" + this.stamp + ".txt", "carcheck_latest.txt"}) {
                        FileOutputStream fileOutputStream = new FileOutputStream(new File(file, str));
                        fileOutputStream.write(bytes);
                        fileOutputStream.close();
                    }
                    sb.append(new File(file, "carcheck_latest.txt").getAbsolutePath()).append('\n');
                } catch (Throwable th) {
                    sb.append("write failed ").append(file).append(": ").append(th).append('\n');
                }
            }
        } catch (Throwable th2) {
            sb.append("save error: ").append(th2);
        }
        if (sb.length() == 0) {
            sb.append("no writable location found");
        }
        return sb.toString();
    }

    String sh(String str) {
        try {
            Process processStart = new ProcessBuilder("sh", "-c", str).redirectErrorStream(true).start();
            InputStream inputStream = processStart.getInputStream();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[4096];
            long jCurrentTimeMillis = System.currentTimeMillis() + 6000;
            while (System.currentTimeMillis() < jCurrentTimeMillis) {
                int iAvailable = inputStream.available();
                if (iAvailable > 0) {
                    int i = inputStream.read(bArr, 0, Math.min(iAvailable, bArr.length));
                    if (i < 0) {
                        break;
                    }
                    byteArrayOutputStream.write(bArr, 0, i);
                    if (byteArrayOutputStream.size() > 200000) {
                        break;
                    }
                } else {
                    try {
                        processStart.exitValue();
                        if (inputStream.available() <= 0) {
                            break;
                        }
                    } catch (IllegalThreadStateException e) {
                        Thread.sleep(40L);
                    }
                }
            }
            processStart.destroy();
            return byteArrayOutputStream.toString("UTF-8");
        } catch (Throwable th) {
            return "ERR " + th;
        }
    }

    void shutdown() {
        this.recording = false;
        Iterator<ServiceConnection> it = this.conns.iterator();
        while (it.hasNext()) {
            this.ctx.unbindService(it.next());
        }
        this.conns.clear();
    }

    void snapshot(String str) {
        int i;
        Map<String, Long> mapDecodeAll = decodeAll();
        if (this.lastSnap == null) {
            this.log.line("SNAP(" + str + ") FULL (" + mapDecodeAll.size() + " signals):");
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Long> entry : mapDecodeAll.entrySet()) {
                sb.append(entry.getKey()).append('=').append(entry.getValue()).append("  ");
                if (sb.length() > 130) {
                    this.log.line("  " + ((Object) sb));
                    sb.setLength(0);
                }
            }
            if (sb.length() > 0) {
                this.log.line("  " + ((Object) sb));
            }
        } else {
            StringBuilder sb2 = new StringBuilder();
            int i2 = 0;
            for (Map.Entry<String, Long> entry2 : mapDecodeAll.entrySet()) {
                Long l = this.lastSnap.get(entry2.getKey());
                if (l == null || !l.equals(entry2.getValue())) {
                    sb2.append(entry2.getKey()).append(' ').append(l).append("->").append(entry2.getValue()).append("  ");
                    i = i2 + 1;
                    if (sb2.length() > 130) {
                        this.log.line("  " + ((Object) sb2));
                        sb2.setLength(0);
                    }
                } else {
                    i = i2;
                }
                i2 = i;
            }
            if (sb2.length() > 0) {
                this.log.line("  " + ((Object) sb2));
            }
            this.log.line("SNAP(" + str + ") changed signals since previous snapshot: " + i2);
        }
        synchronized (this.frames) {
            for (int i3 = 0; i3 < this.frames.size(); i3++) {
                this.log.line("  RAW " + this.frames.keyAt(i3) + ": " + Bx.hex(this.frames.valueAt(i3), 16));
            }
        }
        this.lastSnap = mapDecodeAll;
    }

    void startRecording(int i) {
        if (this.recording) {
            this.recEnd += ((long) i) * 1000;
            this.log.line("recording extended by " + i + " s");
        } else {
            this.recording = true;
            this.recEnd = System.currentTimeMillis() + (((long) i) * 1000);
            async(new Runnable() { // from class: com.carcheck.app.Runner.19
                @Override // java.lang.Runnable
                public void run() {
                    Runner.this.log.section("RECORDING (do the actions, press the matching button after each)");
                    for (int i2 = 1; i2 <= 4; i2++) {
                        Runner.this.fetchCan(i2, true);
                    }
                    Runner.this.snapshot("recording start");
                    int i3 = 0;
                    while (Runner.this.recording && System.currentTimeMillis() < Runner.this.recEnd) {
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e) {
                        }
                        Runner.this.sample();
                        i3++;
                        if (i3 % 3 == 0) {
                            Runner.this.save();
                        }
                    }
                    Runner.this.recording = false;
                    for (int i4 = 1; i4 <= 4; i4++) {
                        Runner.this.fetchCan(i4, true);
                    }
                    Runner.this.snapshot("recording end");
                    Runner.this.keepAlive(false);
                    Runner.this.log.section("RECORDING FINISHED");
                    String strSave = Runner.this.save();
                    if (Runner.this.done != null) {
                        Runner.this.done.onDone(strSave);
                    }
                }
            });
        }
    }

    void step(String str, final Runnable runnable) {
        this.log.section(str);
        final boolean[] zArr = {false};
        Thread thread = new Thread(new Runnable() { // from class: com.carcheck.app.Runner.6
            @Override // java.lang.Runnable
            public void run() {
                try {
                    runnable.run();
                } catch (Throwable th) {
                    Runner.this.log.line("EXCEPTION: " + th);
                } finally {
                    zArr[0] = true;
                }
            }
        });
        thread.setDaemon(true);
        thread.start();
        try {
            thread.join(25000L);
        } catch (InterruptedException e) {
        }
        if (zArr[0]) {
            return;
        }
        this.log.line("TIMEOUT after 25 s - step abandoned (service may be blocking)");
    }

    void stopRecording() {
        this.recording = false;
    }

    void tBt() {
        this.btB = Bx.sm("zhbt_service");
        if (this.btB == null) {
            this.log.line("zhbt_service: NOT registered right now (connect/phone state may matter; re-run with a phone connected)");
        } else {
            this.log.line("descriptor = " + desc(this.btB));
            for (int i = 1; i <= 3; i++) {
                try {
                    Bx.call(this.btB, D_BT, 3, Integer.valueOf(i), this.btCb).recycle();
                    this.log.line("registerCallback(domain " + i + ") OK");
                } catch (Throwable th) {
                    this.log.line("registerCallback(domain " + i + ") failed: " + th);
                }
            }
        }
        btReads();
    }

    void tCan() {
        this.canB = bind(new Intent().setClassName("com.zhonghong.can", "com.zhonghong.can.CanService"), 5000, "CanService");
        if (this.canB == null) {
            return;
        }
        this.log.line("descriptor = " + desc(this.canB));
        try {
            Bx.call(this.canB, D_CAN, 1, this.canCb).recycle();
            this.log.line("registerCallback OK");
        } catch (Throwable th) {
            this.log.line("registerCallback failed: " + th);
        }
        int i = 1;
        boolean z = false;
        while (i <= 4) {
            boolean zFetchCan = fetchCan(i, false) | z;
            i++;
            z = zFetchCan;
        }
        this.log.line("getElementDataInfo returned data: " + z);
        this.lastEvt = decodeAll();
        snapshot("initial");
    }

    void tEnv() {
        String string;
        this.log.line("MODEL=" + Build.MODEL + " DEVICE=" + Build.DEVICE + " SDK=" + Build.VERSION.SDK_INT + " FINGERPRINT=" + Build.FINGERPRINT);
        this.log.line("DISPLAY=" + this.ctx.getResources().getDisplayMetrics());
        this.log.line("id: " + sh("id").trim());
        for (String str : new String[]{"ro.boot.selinux", "sys.btcall", "sys.innavi", "sys.carlifevr", "sys.stream.duckvalue", "zh.navi.pidlist", "CarSettingKey", "ro.kernel.android.mcu", "ro.kernel.android.gps", "ro.kernel.android.bt", "ro.mcu.baudRate", "persist.sys.default.launcher", "persist.sys.default_navi", "persist.zh.login", "sys.zh.login", "ro.build.zhonghongpackage", "ro.boot.hardwarever"}) {
            this.log.line("prop " + str + " = " + Bx.prop(str));
        }
        ContentResolver contentResolver = this.ctx.getContentResolver();
        for (String str2 : new String[]{"back_state", "bt_connected", "key_bluetooth_state", "key_signal_state", "key_battery_state", "navi_mix_value", "screen_brightness", "screen_brightness_mode", "radio_rds_enbale", "system_state_aux", "key_type_car_level", "time_12_24", "CAR_ENGINE_OIL_CHANGE_TYPE", "CAR_ENGINE_OIL_CHANGE_REMAIN_TYPE", "CAR_ENGINE_OIR_FILTER_CHANGE_TYPE", "CAR_ENGINE_OIR_FILTER_CHANGE_REMAIN_TYPE", "CAR_ENGINE_AIR_FILTER_CHANGE_TYPE", "CAR_ENGINE_AIR_FILTER_CHANGE_REMAIN_TYPE", "CAR_FUEL_FILTER_CHANGE_TYPE", "CAR_FUEL_FILTER_CHANGE_REMAIN_TYPE"}) {
            try {
                string = Settings.System.getString(contentResolver, str2);
            } catch (Throwable th) {
                string = "<err " + th + ">";
            }
            Log log = this.log;
            StringBuilder sbAppend = new StringBuilder().append("Settings.System ").append(str2).append(" = ");
            if (string == null) {
                string = "<null>";
            }
            log.line(sbAppend.append(string).toString());
        }
        AudioManager audioManager = (AudioManager) this.ctx.getSystemService("audio");
        for (int i = 0; i <= 11; i++) {
            try {
                this.log.line("audio stream " + i + ": vol=" + audioManager.getStreamVolume(i) + " max=" + audioManager.getStreamMaxVolume(i));
            } catch (Throwable th2) {
                this.log.line("audio stream " + i + ": " + th2.getClass().getSimpleName());
            }
        }
        this.log.line("music active=" + audioManager.isMusicActive() + " mode=" + audioManager.getMode());
        try {
            this.log.line("GPS provider enabled=" + ((LocationManager) this.ctx.getSystemService("location")).isProviderEnabled("gps"));
        } catch (Throwable th3) {
            this.log.line("GPS provider: " + th3);
        }
        PackageManager packageManager = this.ctx.getPackageManager();
        for (String str3 : new String[]{"com.zhonghong.can", "com.zhonghong.logic", "com.zhonghong.mcu", "com.zhonghong.bluetooth", "com.zhonghong.aidlserver", "com.zhonghong.yzmusic", "com.zhonghong.yzvideo", "com.zhonghong.mediascan2", "com.zh.yzradio", "com.zh.settings", "com.zhonghong.carsetting", "com.zhonghong.launcher", "com.car.phoneprovider", "com.zh.auxin", "com.zhonghong.screensaver", "com.zhonghong.update", "com.zhonghong.avm", "com.zhonghong.carlife", "com.zhonghong.phonelink", "com.zhonghong.power", "com.zhonghong.zuiserver", "com.zhonghong.radio", "net.easyconn", "com.estrongs.android.pop", "com.xbrowser.play", "com.chartcross.gpstest", "com.polstar.polnav6", "org.rajman.neshan.traffic.tehran.navigator", "com.google.android.apps.maps", "com.android.packageinstaller"}) {
            try {
                PackageInfo packageInfo = packageManager.getPackageInfo(str3, 0);
                this.log.line("pkg " + str3 + " installed v" + packageInfo.versionName + " (" + packageInfo.versionCode + ")");
            } catch (Throwable th4) {
                this.log.line("pkg " + str3 + " NOT installed");
            }
        }
        for (String str4 : new String[]{"a:com.zhonghong.intent.action.music", "a:com.zhonghong.usb_music_activity", "a:com.zhonghong.usb_music_list", "a:com.zhonghong.video_activity", "a:android.bluetooth_btdial", "a:android.bluetooth_btsettings", "a:android.bluetooth_btmusic", "a:com.zhonghong.action.set", "a:com.zhonghong.action.eq", "a:com.zhonghong.launcher.MEDIA_ACTION", "a:com.zhonghong.launcher.NAVI_ACTION", "c:com.zh.yzradio/com.zh.yzradio.MainActivity", "c:com.zhonghong.carsetting/com.zhonghong.carsetting.MainActivity", "c:com.zh.auxin/com.zh.auxin.MainActivity", "c:com.android.settings/.Settings", "a:android.settings.SETTINGS", "c:com.estrongs.android.pop/com.estrongs.android.pop.view.FileExplorerActivity"}) {
            Intent intent = new Intent();
            if (str4.startsWith("a:")) {
                intent.setAction(str4.substring(2));
            } else {
                intent.setComponent(ComponentName.unflattenFromString(str4.substring(2)));
            }
            this.log.line("intent " + str4 + " resolves=" + (packageManager.resolveActivity(intent, 0) != null));
        }
    }

    void tLogic() {
        this.logicB = Bx.sm("_logic_service");
        if (this.logicB == null) {
            this.log.line("_logic_service: not found");
            return;
        }
        this.log.line("descriptor = " + desc(this.logicB));
        for (String str : new String[]{"isAccOn", "isPowerOn", "isInBackState", "isIllon", "isRunning", "getAvmState", "isAuxState", "getSourceId", "getThirdSourceId", "getFocusState"}) {
            try {
                Parcel parcelCall = Bx.call(this.logicB, D_LOGIC, 4, str, "");
                this.log.line("getValue(" + str + ") = " + parcelCall.readString());
                parcelCall.recycle();
            } catch (Throwable th) {
                this.log.line("getValue(" + str + ") failed: " + th);
            }
        }
        for (String str2 : new String[]{"0", "1", "3", "13", "14"}) {
            try {
                Parcel parcelCall2 = Bx.call(this.logicB, D_LOGIC, 4, "hasFocusById", str2);
                String string = parcelCall2.readString();
                parcelCall2.recycle();
                Parcel parcelCall3 = Bx.call(this.logicB, D_LOGIC, 4, "getFocusStateById", str2);
                this.log.line("source id " + str2 + ": hasFocus=" + string + " focusState=" + parcelCall3.readString());
                parcelCall3.recycle();
            } catch (Throwable th2) {
                this.log.line("focus query id " + str2 + " failed: " + th2);
            }
        }
        try {
            Bx.call(this.logicB, D_LOGIC, 1, 1, this.logicCb).recycle();
            this.log.line("registerLogicCallback OK (events will be logged as EVENT logic)");
        } catch (Throwable th3) {
            this.log.line("registerLogicCallback failed: " + th3);
        }
    }

    void tMcu() {
        this.mcuB = Bx.sm("zhonghong.mcu");
        if (this.mcuB == null) {
            this.log.line("zhonghong.mcu: not found");
            return;
        }
        this.log.line("descriptor = " + desc(this.mcuB));
        Parcel parcelObtain = Parcel.obtain();
        Parcel parcelObtain2 = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(D_MCU);
            this.mcuB.transact(2, parcelObtain, parcelObtain2, 0);
            parcelObtain2.setDataPosition(0);
            this.log.line("getTest() = " + parcelObtain2.readInt());
        } catch (Throwable th) {
            this.log.line("getTest failed: " + th);
        } finally {
            parcelObtain.recycle();
            parcelObtain2.recycle();
        }
        mcuReads();
    }

    void tOverlay() {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        final String[] strArr = {"not run"};
        this.act.runOnUiThread(new Runnable() { // from class: com.carcheck.app.Runner.18
            @Override // java.lang.Runnable
            public void run() {
                try {
                    final WindowManager windowManager = (WindowManager) Runner.this.ctx.getSystemService("window");
                    final TextView textView = new TextView(Runner.this.ctx);
                    textView.setText("  CarCheck overlay test  ");
                    textView.setTextSize(20.0f);
                    textView.setBackgroundColor(-14531448);
                    textView.setTextColor(-1);
                    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2002, 24, -3);
                    layoutParams.gravity = 81;
                    windowManager.addView(textView, layoutParams);
                    strArr[0] = "OK: TYPE_PHONE overlay added";
                    Runner.this.main.postDelayed(new Runnable() { // from class: com.carcheck.app.Runner.18.1
                        @Override // java.lang.Runnable
                        public void run() {
                            try {
                                windowManager.removeView(textView);
                            } catch (Throwable th) {
                            }
                            countDownLatch.countDown();
                        }
                    }, 1500L);
                } catch (Throwable th) {
                    strArr[0] = "FAILED: " + th;
                    countDownLatch.countDown();
                }
            }
        });
        try {
            countDownLatch.await(6L, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
        }
        this.log.line("overlay window: " + strArr[0]);
    }

    void tProviders() throws Throwable {
        describe("content://com.zhonghong.bluetooth.provider.btinfo/btbase", true);
        describe("content://com.zhonghong.bluetooth.provider.btinfo/btmusic", true);
        describe("content://com.zhonghong.bluetooth.provider.btinfo/btcontacts", false);
        describe("content://com.car.phone_data/contacts", false);
        describe("content://com.car.phone_data/call_log", false);
        describe("content://com.car.phone_data/contacts_favorite", false);
        describe("content://com.zhonghong.media/audio", false);
        describe("content://com.zhonghong.media/video", false);
        describe("content://com.zhonghong.media/image", false);
        describe("content://com.zhonghong.media/txt", false);
        describe("content://com.zhonghong.media/id3", false);
        describe("content://com.zhonghong.media/scan_state", true);
    }

    void tProvidersBtOnly() throws Throwable {
        describe("content://com.zhonghong.bluetooth.provider.btinfo/btbase", true);
        describe("content://com.zhonghong.bluetooth.provider.btinfo/btmusic", true);
    }

    void tServices() {
        String[] strArrListServices = Bx.listServices();
        if (strArrListServices == null) {
            this.log.line("ServiceManager.listServices not available via reflection");
        } else {
            this.log.line("service count = " + strArrListServices.length);
            for (String str : strArrListServices) {
                String lowerCase = str.toLowerCase(Locale.US);
                if (lowerCase.contains("zh") || lowerCase.contains("logic") || lowerCase.contains("mcu") || lowerCase.contains("bt") || lowerCase.contains("can") || lowerCase.contains("state") || lowerCase.contains("update") || lowerCase.contains("aidl") || lowerCase.contains("yz")) {
                    this.log.line("  service: " + str);
                }
            }
        }
        for (String str2 : new String[]{"zhbt_service", "zh_can_service", "_logic_service", "zhonghong.mcu", "zhupdate_service"}) {
            IBinder iBinderSm = Bx.sm(str2);
            this.log.line("getService(\"" + str2 + "\") -> " + (iBinderSm == null ? "null" : "binder, descriptor=" + desc(iBinderSm)));
        }
        this.log.line("shell 'service list' filtered:\n" + sh("service list | grep -i -E 'zh|logic|mcu|bt|can|state|yz|update'"));
    }

    void tState() {
        this.stateB = bind(new Intent().setClassName("com.zhonghong.aidlserver", "com.zhonghong.aidlserver.service.SystemStateService"), 5000, "SystemStateService");
        if (this.stateB != null) {
            this.log.line("descriptor = " + desc(this.stateB));
            int[] iArr = {4, 5, 6};
            String[] strArr = {"getNetworkState", "getBluetoothConnectState", "getBluetoothInCallState"};
            for (int i = 0; i < iArr.length; i++) {
                try {
                    Parcel parcelCall = Bx.call(this.stateB, D_STATE, iArr[i], new Object[0]);
                    this.log.line(strArr[i] + " = " + (parcelCall.readInt() != 0));
                    parcelCall.recycle();
                } catch (Throwable th) {
                    this.log.line(strArr[i] + " failed: " + th);
                }
            }
            try {
                Parcel parcelCall2 = Bx.call(this.stateB, D_STATE, 3, new Object[0]);
                parcelCall2.readInt();
                parcelCall2.recycle();
                this.log.line("getTuidNumber() call OK (value hidden)");
            } catch (Throwable th2) {
                this.log.line("getTuidNumber failed: " + th2);
            }
            try {
                Bx.call(this.stateB, D_STATE, 1, this.stateCb).recycle();
                this.log.line("registerCallBack OK (events will be logged as EVENT state)");
            } catch (Throwable th3) {
                this.log.line("registerCallBack failed: " + th3);
            }
        }
        IBinder iBinderBind = bind(new Intent().setClassName("com.zhonghong.aidlserver", "com.zhonghong.aidlserver.service.SystemStateService2"), 4000, "SystemStateService2");
        if (iBinderBind != null) {
            this.log.line("SystemStateService2 descriptor = " + desc(iBinderBind));
        }
    }

    void tUsb() {
        this.usbB = bind(new Intent().setClassName("com.zhonghong.yzmusic", "com.zhonghong.music.model.service.UsbMusicService"), 5000, "UsbMusicService");
        if (this.usbB != null) {
            this.log.line("descriptor = " + desc(this.usbB));
            try {
                Parcel parcelCall = Bx.call(this.usbB, D_USB, 3, new Object[0]);
                this.log.line("isPlaying = " + (parcelCall.readInt() != 0));
                parcelCall.recycle();
                String[] strArr = {"getTitle", "getArtist", "getAlbum"};
                int[] iArr = {4, 6, 5};
                for (int i = 0; i < 3; i++) {
                    Parcel parcelCall2 = Bx.call(this.usbB, D_USB, iArr[i], new Object[0]);
                    String string = parcelCall2.readString();
                    parcelCall2.recycle();
                    this.log.line(strArr[i] + " -> length " + len(string));
                }
                Bx.call(this.usbB, D_USB, 1, this.usbCb).recycle();
                this.log.line("registerDataChange OK (events logged as EVENT usbmusic)");
            } catch (Throwable th) {
                this.log.line("usb music calls failed: " + th);
            }
        }
        this.videoB = bind(new Intent().setClassName("com.zhonghong.yzvideo", "com.zhonghong.yzvideo.service.VideoService"), 5000, "VideoService");
        if (this.videoB != null) {
            this.log.line("descriptor = " + desc(this.videoB));
            try {
                Parcel parcelCall3 = Bx.call(this.videoB, D_VIDEO, 3, new Object[0]);
                this.log.line("video isPlaying = " + (parcelCall3.readInt() != 0));
                parcelCall3.recycle();
            } catch (Throwable th2) {
                this.log.line("video isPlaying failed: " + th2);
            }
        }
    }
}
