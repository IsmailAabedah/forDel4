package com.carcheck.app;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ConcurrentLinkedQueue;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends Activity {
    private static Log LOG;
    private static final String[][] MARKS = {new String[]{"-- الأبواب", ""}, new String[]{"فتحت باب السائق", "DRIVER_DOOR_OPENED"}, new String[]{"أغلقت باب السائق", "DRIVER_DOOR_CLOSED"}, new String[]{"فتحت باب الراكب", "PASSENGER_DOOR_OPENED"}, new String[]{"أغلقت باب الراكب", "PASSENGER_DOOR_CLOSED"}, new String[]{"فتحت باب خلفي يسار", "REAR_LEFT_DOOR_OPENED"}, new String[]{"أغلقته", "REAR_LEFT_DOOR_CLOSED"}, new String[]{"فتحت باب خلفي يمين", "REAR_RIGHT_DOOR_OPENED"}, new String[]{"أغلقته", "REAR_RIGHT_DOOR_CLOSED"}, new String[]{"فتحت الصندوق", "TRUNK_OPENED"}, new String[]{"أغلقت الصندوق", "TRUNK_CLOSED"}, new String[]{"فتحت الكبوت", "BONNET_OPENED"}, new String[]{"أغلقت الكبوت", "BONNET_CLOSED"}, new String[]{"-- الأحزمة والفرامل", ""}, new String[]{"ربطت حزام السائق", "DRIVER_BELT_FASTENED"}, new String[]{"فككت حزام السائق", "DRIVER_BELT_UNFASTENED"}, new String[]{"ربطت حزام الراكب", "PASSENGER_BELT_FASTENED"}, new String[]{"فككت حزام الراكب", "PASSENGER_BELT_UNFASTENED"}, new String[]{"رفعت فرامل اليد", "HANDBRAKE_ON"}, new String[]{"أنزلت فرامل اليد", "HANDBRAKE_OFF"}, new String[]{"ضغطت الفرامل", "BRAKE_PEDAL_PRESSED"}, new String[]{"أفلتّ الفرامل", "BRAKE_PEDAL_RELEASED"}, new String[]{"-- الأضواء", ""}, new String[]{"أضواء صغيرة ON", "POSITION_LIGHTS_ON"}, new String[]{"الأضواء القريبة ON", "LOW_BEAM_ON"}, new String[]{"الأضواء البعيدة ON", "HIGH_BEAM_ON"}, new String[]{"كل الأضواء OFF", "LIGHTS_ALL_OFF"}, new String[]{"ضباب أمامي ON", "FRONT_FOG_ON"}, new String[]{"ضباب خلفي ON", "REAR_FOG_ON"}, new String[]{"إشارة يسار", "INDICATOR_LEFT_ON"}, new String[]{"إشارة يمين", "INDICATOR_RIGHT_ON"}, new String[]{"إشارات OFF", "INDICATORS_OFF"}, new String[]{"خطر ON", "HAZARD_ON"}, new String[]{"خطر OFF", "HAZARD_OFF"}, new String[]{"-- الغيار والتشغيل", ""}, new String[]{"الغيار الخلفي ON", "REVERSE_ON"}, new String[]{"الغيار الخلفي OFF", "REVERSE_OFF"}, new String[]{"الغيار N", "GEAR_NEUTRAL"}, new String[]{"الغيار D", "GEAR_DRIVE"}, new String[]{"المفتاح ACC", "KEY_ACC"}, new String[]{"المفتاح ON", "KEY_ON"}, new String[]{"المحرك شغّال", "ENGINE_RUNNING"}, new String[]{"المحرك مطفأ", "ENGINE_OFF"}, new String[]{"-- القفل والمسّاحات والزجاج", ""}, new String[]{"قفل مركزي", "CENTRAL_LOCK"}, new String[]{"فتح القفل", "CENTRAL_UNLOCK"}, new String[]{"مسّاحة ON", "WIPER_ON"}, new String[]{"مسّاحة OFF", "WIPER_OFF"}, new String[]{"زجاج السائق نزل", "WINDOW_DRIVER_DOWN"}, new String[]{"زجاج السائق طلع", "WINDOW_DRIVER_UP"}, new String[]{"-- الهاتف والوسائط", ""}, new String[]{"مكالمة واردة الآن", "CALL_INCOMING"}, new String[]{"أجبت المكالمة", "CALL_ANSWERED"}, new String[]{"انتهت المكالمة", "CALL_ENDED"}, new String[]{"غيّرت الصوت", "VOLUME_CHANGED"}, new String[]{"الراديو يعمل", "RADIO_PLAYING"}, new String[]{"غيّرت المحطة", "RADIO_STATION_CHANGED"}, new String[]{"شغّلت موسيقى USB", "USB_MUSIC_PLAYING"}, new String[]{"أوقفت الموسيقى", "USB_MUSIC_PAUSED"}};
    private static Runner RUNNER;
    private float d;
    private Log log;
    private ScrollView logScroll;
    private TextView logView;
    private Runner runner;
    private TextView status;
    private final Handler ui = new Handler();
    private final ConcurrentLinkedQueue<String> pending = new ConcurrentLinkedQueue<>();
    private final StringBuilder shown = new StringBuilder();
    private boolean started = false;

    /* JADX INFO: renamed from: com.carcheck.app.MainActivity$1, reason: invalid class name */
    class AnonymousClass1 implements View.OnClickListener {
        AnonymousClass1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (MainActivity.this.started) {
                return;
            }
            MainActivity.this.started = true;
            ((Button) view).setText("الفحص يعمل...");
            MainActivity.this.runner.done = new Runner.Done() { // from class: com.carcheck.app.MainActivity.1.1
                @Override // com.carcheck.app.Runner.Done
                public void onDone(final String str) {
                    MainActivity.this.ui.post(new Runnable() { // from class: com.carcheck.app.MainActivity.1.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            MainActivity.this.status.setText("انتهى التسجيل. التقرير:\n" + str);
                        }
                    });
                }
            };
            new Thread(new Runnable() { // from class: com.carcheck.app.MainActivity.1.2
                @Override // java.lang.Runnable
                public void run() {
                    MainActivity.this.runner.runStatic();
                    MainActivity.this.runner.startRecording(150);
                }
            }).start();
        }
    }

    private Button btn(String str, int i) {
        Button button = new Button(this);
        button.setText(str);
        button.setTextSize(2, i);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(4), dp(6), dp(4), dp(6));
        return button;
    }

    private int dp(int i) {
        return (int) ((i * this.d) + 0.5f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void tick() {
        boolean z = false;
        while (true) {
            String strPoll = this.pending.poll();
            if (strPoll == null) {
                break;
            }
            this.shown.append(strPoll).append('\n');
            z = true;
        }
        if (z) {
            if (this.shown.length() > 14000) {
                this.shown.delete(0, this.shown.length() - 12000);
            }
            this.logView.setText(this.shown.toString());
            this.logScroll.post(new Runnable() { // from class: com.carcheck.app.MainActivity.9
                @Override // java.lang.Runnable
                public void run() {
                    MainActivity.this.logScroll.fullScroll(130);
                }
            });
        }
        if (this.runner.recording) {
            this.status.setText("يسجّل الآن... المتبقي " + Math.max(0L, (this.runner.recEnd - System.currentTimeMillis()) / 1000) + " ث. نفّذ الإجراءات واضغط الأزرار.");
        } else if (this.runner.staticRunning) {
            this.status.setText("الفحص الثابت يعمل، انتظر...");
        }
        this.ui.postDelayed(new Runnable() { // from class: com.carcheck.app.MainActivity.10
            @Override // java.lang.Runnable
            public void run() {
                MainActivity.this.tick();
            }
        }, 500L);
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.d = getResources().getDisplayMetrics().density;
        getWindow().addFlags(128);
        if (RUNNER == null) {
            LOG = new Log();
            RUNNER = new Runner(this, LOG);
        } else {
            RUNNER.act = this;
        }
        this.log = LOG;
        this.runner = RUNNER;
        this.started = this.runner.everStarted;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setBackgroundColor(-15723236);
        linearLayout.setPadding(dp(6), dp(30), dp(6), dp(6));
        ScrollView scrollView = new ScrollView(this);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setPadding(dp(4), dp(2), dp(4), dp(8));
        scrollView.addView(linearLayout2);
        TextView textView = new TextView(this);
        textView.setText("CarCheck: فحص الخدمات");
        textView.setTextColor(-1);
        textView.setTextSize(2, 17.0f);
        textView.setTypeface(Typeface.DEFAULT, 1);
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText("1) شغّل السيارة (ACC أو المحرك) وأوقفها.\n2) اضغط «ابدأ الفحص الكامل» وانتظر انتهاء الفحص الثابت (دقيقة تقريبًا).\n3) أثناء التسجيل نفّذ الإجراءات واحدًا واحدًا، واضغط الزر المقابل بعد كل إجراء.\n4) في النهاية يُحفظ التقرير تلقائيًا على الفلاشة وعلى الذاكرة (carcheck_latest.txt).");
        textView2.setTextColor(-6310968);
        textView2.setTextSize(2, 12.0f);
        linearLayout2.addView(textView2);
        Button buttonBtn = btn(this.started ? "الفحص يعمل / انتهى" : "ابدأ الفحص الكامل", 15);
        linearLayout2.addView(buttonBtn, new LinearLayout.LayoutParams(-1, -2));
        buttonBtn.setOnClickListener(new AnonymousClass1());
        this.status = new TextView(this);
        this.status.setTextColor(-11870592);
        this.status.setTextSize(2, 12.0f);
        this.status.setText("لم يبدأ بعد");
        linearLayout2.addView(this.status);
        LinearLayout linearLayout3 = new LinearLayout(this);
        Button buttonBtn2 = btn("+60 ثانية تسجيل", 12);
        Button buttonBtn3 = btn("إيقاف وحفظ الآن", 12);
        linearLayout3.addView(buttonBtn2, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout3.addView(buttonBtn3, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(linearLayout3);
        buttonBtn2.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.runner.startRecording(60);
            }
        });
        buttonBtn3.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.runner.stopRecording();
            }
        });
        LinearLayout linearLayout4 = new LinearLayout(this);
        Button buttonBtn4 = btn("قراءة MCU الآن", 12);
        Button buttonBtn5 = btn("قراءة البلوتوث/المكالمة الآن", 12);
        Button buttonBtn6 = btn("اختبار الصفارة", 12);
        linearLayout4.addView(buttonBtn4, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout4.addView(buttonBtn5, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout4.addView(buttonBtn6, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(linearLayout4);
        buttonBtn4.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.runner.quickMcu();
            }
        });
        buttonBtn5.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.runner.quickBt();
            }
        });
        buttonBtn6.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.runner.beepTest();
            }
        });
        LinearLayout linearLayout5 = null;
        int i = 0;
        for (final String[] strArr : MARKS) {
            if (strArr[1].length() == 0) {
                TextView textView3 = new TextView(this);
                textView3.setText(strArr[0].substring(3));
                textView3.setTextColor(-7092739);
                textView3.setTextSize(2, 13.0f);
                textView3.setTypeface(Typeface.DEFAULT, 1);
                textView3.setPadding(dp(2), dp(8), 0, dp(2));
                linearLayout2.addView(textView3);
                linearLayout5 = null;
            } else {
                if (linearLayout5 == null || i == 3) {
                    linearLayout5 = new LinearLayout(this);
                    linearLayout2.addView(linearLayout5);
                    i = 0;
                }
                Button buttonBtn7 = btn(strArr[0], 11);
                linearLayout5.addView(buttonBtn7, new LinearLayout.LayoutParams(0, -2, 1.0f));
                i++;
                buttonBtn7.setOnClickListener(new View.OnClickListener() { // from class: com.carcheck.app.MainActivity.7
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        MainActivity.this.runner.mark(strArr[1]);
                        if (strArr[1].startsWith("CALL_")) {
                            MainActivity.this.runner.quickBt();
                        }
                        if (strArr[1].startsWith("RADIO_") || strArr[1].startsWith("VOLUME_")) {
                            MainActivity.this.runner.quickMcu();
                        }
                    }
                });
            }
        }
        linearLayout.addView(scrollView, new LinearLayout.LayoutParams(0, -1, 1.15f));
        this.logScroll = new ScrollView(this);
        this.logView = new TextView(this);
        this.logView.setTextColor(-3024410);
        this.logView.setTextSize(2, 9.0f);
        this.logView.setTypeface(Typeface.MONOSPACE);
        this.logView.setGravity(3);
        this.logScroll.addView(this.logView);
        linearLayout.addView(this.logScroll, new LinearLayout.LayoutParams(0, -1, 1.0f));
        setContentView(linearLayout);
        String strText = this.log.text();
        if (strText.length() > 12000) {
            strText = strText.substring(strText.length() - 12000);
        }
        this.shown.append(strText);
        this.logView.setText(this.shown.toString());
        this.log.sink = new Log.Sink() { // from class: com.carcheck.app.MainActivity.8
            @Override // com.carcheck.app.Log.Sink
            public void onLine(String str) {
                MainActivity.this.pending.add(str);
            }
        };
        tick();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.log.sink = null;
    }
}
