package com.carcheck.app;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: classes.dex */
final class Bx {
    Bx() {
    }

    static long bits(byte[] bArr, int i, int i2, int i3) {
        if (bArr == null) {
            return -1L;
        }
        long j = 0;
        for (int i4 = 0; i4 < i3; i4++) {
            int i5 = ((i + 3) * 8) + i2 + i4;
            int i6 = i5 >> 3;
            if (i6 >= bArr.length) {
                return -1L;
            }
            if (((bArr[i6] >> (i5 & 7)) & 1) != 0) {
                j |= 1 << i4;
            }
        }
        return j;
    }

    static Parcel call(IBinder iBinder, String str, int i, Object... objArr) throws RemoteException {
        Parcel parcelObtain = Parcel.obtain();
        Parcel parcelObtain2 = Parcel.obtain();
        try {
            try {
                parcelObtain.writeInterfaceToken(str);
                for (Object obj : objArr) {
                    if (obj instanceof Integer) {
                        parcelObtain.writeInt(((Integer) obj).intValue());
                    } else if (obj instanceof String) {
                        parcelObtain.writeString((String) obj);
                    } else if (obj instanceof IBinder) {
                        parcelObtain.writeStrongBinder((IBinder) obj);
                    } else if (obj instanceof Boolean) {
                        parcelObtain.writeInt(((Boolean) obj).booleanValue() ? 1 : 0);
                    }
                }
                iBinder.transact(i, parcelObtain, parcelObtain2, 0);
                parcelObtain2.readException();
                parcelObtain.recycle();
                return parcelObtain2;
            } catch (RemoteException e) {
                parcelObtain2.recycle();
                throw e;
            } catch (RuntimeException e2) {
                parcelObtain2.recycle();
                throw e2;
            }
        } catch (Throwable th) {
            parcelObtain.recycle();
            throw th;
        }
    }

    static String hex(byte[] bArr, int i) {
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < bArr.length && i2 < i; i2++) {
            sb.append(String.format("%02X ", Byte.valueOf(bArr[i2])));
        }
        return sb.toString().trim();
    }

    static String[] listServices() {
        try {
            return (String[]) Class.forName("android.os.ServiceManager").getMethod("listServices", new Class[0]).invoke(null, new Object[0]);
        } catch (Throwable th) {
            return null;
        }
    }

    static String prop(String str) {
        try {
            return (String) Class.forName("android.os.SystemProperties").getMethod("get", String.class, String.class).invoke(null, str, "<unset>");
        } catch (Throwable th) {
            return "<err " + th + ">";
        }
    }

    static IBinder sm(String str) {
        try {
            return (IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, str);
        } catch (Throwable th) {
            return null;
        }
    }
}
