package com.carcheck.app;

import android.os.SystemClock;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
final class Log {
    volatile Sink sink;
    private final StringBuilder sb = new StringBuilder(65536);
    private final long t0 = SystemClock.elapsedRealtime();

    interface Sink {
        void onLine(String str);
    }

    Log() {
    }

    synchronized void line(String str) {
        String str2 = String.format(Locale.US, "[%8.3f] %s", Double.valueOf((SystemClock.elapsedRealtime() - this.t0) / 1000.0d), str);
        this.sb.append(str2).append('\n');
        Sink sink = this.sink;
        if (sink != null) {
            sink.onLine(str2);
        }
    }

    void section(String str) {
        line("");
        line("===== " + str + " =====");
    }

    synchronized String text() {
        return this.sb.toString();
    }
}
